<h1>DLC Plugin</h1>

<h3>What this plugin does</h3>

<ul>
     <lh><h4>Front End</h4></lh>
          <li>- initialize sessions from old site</li>
          <li>- get login status</li>
          <li>- get password reset status</li>
          <li>- load conditional login menu</li>
          <li>- change admin login logo/url</li>
          <li>- load custom css</li>
          <li>- load custom js</li>
     <lh><h4>Admin</h4></lh>
          <li>- create custom post type</li>
          <li>- load settings page</li>
</ul>
<br><br>
<pre>
A knight is sworn to valor
His heart knows only virtue
His blade defends the helpless
His might upholds the weak
His words speak only truth
His wrath undoes the wicked
</pre>
