<?php
print_r($_SESSION);
$title = get_page_by_title( 'Products', '', 'page' );
$url_products = get_permalink($title->ID);
?>

<p><iframe src="https://www.youtube.com/embed/XfecVverhHw?rel=0&amp;autoplay=1" width="800" height="450" frameborder="0" allowfullscreen="allowfullscreen"></iframe></p>

<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link" href="<?php echo $url_products; ?>">BUY PRODUCTS</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph -->
<p>Choose from our wide selection of <em>safe, natural, and eco-friendly products</em></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link" href="/reg/package.php">BE ONE OF US</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph -->
<p>Become one of our amazing distributors and <em>Turn Your Expenses into Income</em></p>
<!-- /wp:paragraph --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link" href="/reg/package.php?reseller=1">RESELLER</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons -->

<!-- wp:paragraph -->
<p>Want to become a <strong>Reseller</strong>, or maybe just looking for discounts?</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->
