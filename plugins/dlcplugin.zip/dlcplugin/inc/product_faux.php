<?php
/**
*@package DLCPlugin
*/

class DLCPluginProducts
{

     public function __construct() {
          $this->plugin = plugin_basename( __FILE__ );
          add_filter( 'the_content', array( $this, 'product_pages' ) );
     }

     /**
     * Internally registers pages we want to product. Array key is the slug under which it is being available from the frontend
     * @return mixed
     */
     private static function get_product_pages() {
          global $post;
          if ( is_page() && $post->post_title == 'Products' ) {

               //http://example.com/productpage1
               $product_pages['productpage1'] = array(
                    'title'   => 'Product Page 1',
                    'content' => 'This is a content of Product Page 1'
               );
               //http://example.com/productpage2
               $product_pages['productpage2'] = array(
                    'title'   => 'Product Page 2',
                    'content' => 'This is a content of Product Page 2'
               );

               return $product_pages;
          }
     }

     /**
     * Products get posts result
     *
     * @param $posts
     *
     * @return array|null
     */
     public function product_pages( $posts ) {
          global $wp, $wp_query;
          $product_pages           = self::get_product_pages();

          $product_pages_slugs     = array();
          foreach ( $product_pages as $slug => $fp ) {
               $product_pages_slugs[] = $slug;
          }
          if ( true === in_array( strtolower( $wp->request ), $product_pages_slugs )
               || ( true === isset( $wp->query_vars['page_id'] )
               && true === in_array( strtolower( $wp->query_vars['page_id'] ), $product_pages_slugs )
               )
          ) {
               if ( true === in_array( strtolower( $wp->request ), $product_pages_slugs ) ) {
                    $product_page = strtolower( $wp->request );
               } else {
                    $product_page = strtolower( $wp->query_vars['page_id'] );
               }
               $posts                   = null;
               $posts[]                 = self::create_product_page( $product_page, $product_pages[ $product_page ] );
               $wp_query->is_page       = true;
               $wp_query->is_singular   = true;
               $wp_query->is_home       = false;
               $wp_query->is_archive    = false;
               $wp_query->is_category   = false;
               $wp_query->is_product_page = true;
               $wp_query->product_page  = $wp->request;
               //Longer permalink structures may not match the product post slug and cause a 404 error so we catch the error here
               unset( $wp_query->query["error"] );
               $wp_query->query_vars["error"] = "";
               $wp_query->is_404             = false;
          }
print_r($posts);
          return $posts;
     }

     /**
     * Creates virtual Product Page
     *
     * @param $pagename
     * @param $page
     *
     * @return stdClass
     */
     private static function create_product_page( $pagename, $page ) {
          $post                    = new stdClass;
          $post->post_author       = 1;
          $post->post_name         = $pagename;
          $post->guid              = get_bloginfo( 'wpurl' ) . '/products/' . $pagename;
          $post->post_title        = $page['title'];
          $post->post_content      = $page['content'];
          $post->ID                = - 1;
          $post->post_status       = 'static';
          $post->comment_status    = 'closed';
          $post->ping_status       = 'closed';
          $post->comment_count     = 0;
          $post->post_date         = current_time( 'mysql' );
          $post->post_date_gmt     = current_time( 'mysql', 1 );

          return $post;
     }
}
